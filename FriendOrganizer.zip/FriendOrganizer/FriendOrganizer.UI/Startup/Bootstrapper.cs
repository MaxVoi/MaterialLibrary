﻿using FriendOrganizer.UI.Data;
using FriendOrganizer.UI.ViewModel;
using Unity;

namespace FriendOrganizer.UI.Startup
{
    public class Bootstrapper
    {
        public IUnityContainer Bootstrap()
        {
            var builder = new UnityContainer();
            builder.RegisterType<MainWindow>();
            builder.RegisterType<MainViewModel>();
            builder.RegisterType<IFriendDataService, FriendDataService>();

            return builder;
        }
    }
}
